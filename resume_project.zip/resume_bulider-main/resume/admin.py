from django.contrib import admin
from resume.models import *

# Register your models here.

admin.site.register(User_t)
admin.site.register(Company)
admin.site.register(job_vacancy)
admin.site.register(apply_job)
admin.site.register(templates)



