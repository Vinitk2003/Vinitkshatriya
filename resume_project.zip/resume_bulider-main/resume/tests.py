from django.test import TestCase
from django.utils import timezone

# Create your tests here.

print(timezone.now().strftime("%Y-%m-%d"))